// Runs on moe.alefed.com. Only READS the To-Do list the student already sees (title, type, Start/Continue)
// and sends it to Mthakarti. It never reads passwords, answers or grades, and never clicks lessons or quizzes.
(function () {
  const SB = 'https://valzeoiilqbmmrosspsp.supabase.co';
  const KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZhbHplb2lpbHFibW1yb3NzcHNwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ2NzY0MzksImV4cCI6MjExMDI1MjQzOX0.JawQDFBJz50zM-P03QRNifi3ZiiH6n3ZtDK8oI968GA';
  let last = '', lastAt = 0, badge = null;

  function showBadge(txt, ok) {
    if (!badge) {
      badge = document.createElement('div');
      badge.style.cssText = 'position:fixed;bottom:14px;left:14px;z-index:2147483647;background:#fff;border:2px solid #f06ba8;color:#3b2531;font:600 13px Tahoma,Arial,sans-serif;padding:7px 12px;border-radius:99px;box-shadow:0 4px 14px rgba(0,0,0,.12);direction:rtl;cursor:default';
      document.documentElement.appendChild(badge);
    }
    badge.style.borderColor = ok ? '#3fbf8f' : '#f06ba8';
    badge.textContent = txt;
  }
  function key(t, k) { return (t + '|' + k).replace(/\s+/g, ' ').trim().toLowerCase().slice(0, 200); }

  function read() {
    if (!/#\/todo-list/.test(location.hash)) return null;
    const rows = [...document.querySelectorAll('.todo-list-page-v2__card-row')];
    const body = document.body.innerText || '';
    // only trust the list when no class/type filter is applied and everything is shown
    const filtered = !/All Classes|كل الصفوف|جميع/.test(body) || !/All Activity Types|جميع الأنشطة|كل الأنشطة/.test(body);
    const more = [...document.querySelectorAll('button,a,[role=button]')].some(b => /^(Show More|عرض المزيد)$/i.test((b.innerText || '').trim()));
    const items = rows.map(r => {
      const t = (r.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
      const title = t[0] || '', kind = t[1] || '', action = t.find(x => /^(Start|Continue|ابدأ|تابع|استمر)$/i.test(x)) || '';
      return title ? { key: key(title, kind), title, kind, action } : null;
    }).filter(Boolean);
    const m = body.match(/(\d+)\s+done this week|(\d+)\s*(?:مكتمل|أنجزت)/);
    const empty = !rows.length && /all done|todo-list-all-done/i.test(document.documentElement.innerHTML.slice(0, 400000));
    return { items, doneWeek: m ? +(m[1] || m[2]) : null, complete: !filtered && !more && (rows.length > 0 || empty), more };
  }

  // «Show More» only expands the to-do list (5 items at a time); press it until the whole list is visible
  let expanding = false;
  async function expand() {
    if (expanding || !/#\/todo-list/.test(location.hash)) return;
    expanding = true;
    try {
      for (let i = 0; i < 60; i++) {
        const b = [...document.querySelectorAll('button,a,[role=button]')].find(x => /^(Show More|عرض المزيد)$/i.test((x.innerText || '').trim()));
        if (!b) break;
        showBadge('مذاكرتي: نجمع واجباتك… ' + document.querySelectorAll('.todo-list-page-v2__card-row').length, true);
        b.click(); await new Promise(r => setTimeout(r, 1200));
      }
    } finally { expanding = false; }
  }
  async function sync() {
    if (expanding) return;
    await expand();
    chrome.storage.local.get(['acc'], (d) => {
      const acc = d.acc;
      if (!acc) { showBadge('مذاكرتي: افتح mthakarti.com واضغط «اربط الإضافة»', false); return; }
      const s = read();
      if (!s) { showBadge('مذاكرتي ✓ افتح «To-Do List» عشان نحسب واجباتك', true); return; }
      if (s.more) return; // still expanding; next round
      const sig = JSON.stringify(s.items) + s.doneWeek + s.complete;
      if (sig === last && Date.now() - lastAt < 120000) return;
      fetch(SB + '/rest/v1/rpc/alef_sync', {
        method: 'POST', headers: { 'Content-Type': 'application/json', apikey: KEY, Authorization: 'Bearer ' + KEY },
        body: JSON.stringify({ p_acc: acc.id, p_secret: acc.secret, p_items: s.items, p_done_week: s.doneWeek, p_complete: s.complete })
      }).then(r => r.json()).then(j => {
        if (j && j.ok && !j.skipped) {
          last = sig; lastAt = Date.now();
          if (!s.more) showBadge(j.points ? `مذاكرتي ✓ +${j.points} نقطة 🎉 · باقي ${j.pending} واجب` : `مذاكرتي ✓ متصلة · باقي ${j.pending} واجب`, true);
        }
      }).catch(() => showBadge('مذاكرتي: ما قدرنا نتصل، بنجرب بعد شوي', false));
    });
  }
  setInterval(sync, 8000);
  window.addEventListener('hashchange', () => setTimeout(sync, 2500));
  setTimeout(sync, 4000);
})();
