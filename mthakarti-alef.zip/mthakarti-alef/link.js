// Runs on mthakarti.com: tells the page the extension is installed, and saves the student's
// Mthakarti account link when the student presses «اربط الإضافة». Nothing from Alef is read here.
(function () {
  const VERSION = '1.0.0';
  function announce(linked) { window.postMessage({ type: 'MTH_EXT', v: VERSION, linked: !!linked }, location.origin); }
  chrome.storage.local.get(['acc'], (d) => announce(d.acc && d.acc.id));
  window.addEventListener('message', (e) => {
    if (e.source !== window || e.origin !== location.origin || !e.data) return;
    if (e.data.type === 'MTH_LINK' && e.data.acc && /^[0-9a-f-]{36}$/i.test(e.data.acc.id) && /^[0-9a-f-]{36}$/i.test(e.data.acc.secret)) {
      chrome.storage.local.set({ acc: { id: e.data.acc.id, secret: e.data.acc.secret, name: String(e.data.acc.name || '').slice(0, 30) } }, () => {
        window.postMessage({ type: 'MTH_LINKED' }, location.origin); announce(true);
      });
    }
    if (e.data.type === 'MTH_UNLINK') chrome.storage.local.remove(['acc'], () => announce(false));
    if (e.data.type === 'MTH_PING') chrome.storage.local.get(['acc'], (d) => announce(d.acc && d.acc.id));
  });
})();
